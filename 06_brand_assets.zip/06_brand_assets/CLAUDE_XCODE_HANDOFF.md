# Fytte brand asset handoff for Claude in Xcode

Use this as the single source of truth for implementing the current Fytte brand assets.

## Primary selected asset
Use this logo direction as the canonical choice:

`/home/philip/Lip/projects/fytte_bundle/06_brand_assets/logo/fytte_logo_final_premium_system_v1.png`

Selected variant:
- **Premium**
- deep navy monogram
- gold herb-like food cue
- premium wellness tone
- food-aware, not cliché

## Splash reference
Use this as the splash-screen direction:

`/home/philip/Lip/projects/fytte_bundle/06_brand_assets/splash/fytte_splash_premium_final_v1.png`

## Supporting concept history
If you need to understand evolution or mine earlier options, review:

- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/logo/fytte_logo_concepts_v1.png`
- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/logo/fytte_logo_concepts_v2.png`
- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/logo/fytte_logo_leaf_refinement_v1.png`
- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/logo/fytte_logo_herb_gold_professional_v1.png`

## Brand intent
Fytte should feel:
- premium
- emotionally safe
- intelligent
- trustworthy
- wellness-forward
- food-aware

Fytte should NOT feel like:
- bodybuilding or gym culture
- harsh medical software
- generic AI startup branding
- eco/skincare branding
- cartoon food product branding

## Core visual system
### Colors
Use these as anchors:
- Navy: `#091F40`
- Deep: `#0D3B66`
- Blue: `#1A6FA0`
- Sky: `#2A9FD6`
- Mint: `#66DDAA`
- Coral: `#FF7F6B`
- Gold: `#FFC857`
- Ice: `#E1F5FE`

### Typography
- **Display / emotional moments:** Playfair Display
- **Body / UI / utility:** DM Sans

Do not substitute with generic system-feeling combinations unless technically blocked.

## Logo implementation instructions
Recreate the selected Premium logo direction as production-quality assets.

Deliver these outputs:

1. **Primary logo mark**
   - deep navy monogram structure
   - integrated gold herb-like food cue
   - balanced geometry
   - premium, clean silhouette

2. **Horizontal lockup**
   - icon + wordmark "Fytte"
   - elegant spacing
   - suitable for splash, website header, pitch decks

3. **App icon**
   - rounded square background
   - navy-led
   - centered mark
   - preserve readability at small sizes

4. **Monochrome variants**
   - all navy
   - all white
   - ensure shape still reads clearly

5. **Transparent-background exports**
   - if tooling permits

## Splash screen implementation instructions
Implement a polished iOS splash screen using the selected brand direction.

Requirements:
- deep navy to rich blue gradient background
- centered selected Fytte mark
- gold herb cue preserved
- wordmark below the icon
- minimal composition
- soft glow is okay, but keep it restrained
- optional tiny tagline near bottom:
  - `Know what to eat. Love how you feel.`

Avoid:
- particles everywhere
- too much blur/frosting
- cartoon illustrations
- visual clutter

## Product fit notes
The app is a premium AI-guided nutrition product. It is not just calorie tracking.
Important product themes:
- nourishment
- guidance
- trust
- emotional safety
- health sensitivity
- thoughtful personalization

This is why the logo should suggest food gently, not aggressively.

## If implementing inside iOS / Expo / React Native project
Suggested asset outputs:
- `logo-primary.png`
- `logo-primary@2x.png`
- `logo-primary@3x.png`
- `logo-mark.png`
- `logo-mark-light.png`
- `logo-mark-dark.png`
- `app-icon-1024.png`
- `splash-logo.png`
- `splash-background.png` if separating layers

If vector output is possible, also create:
- `logo-primary.svg`
- `logo-mark.svg`

## Quality bar
Everything should feel:
- investor-deck ready
- App Store ready
- polished enough for a real consumer brand

If forced to choose between flashy and trustworthy, choose trustworthy.
If forced to choose between decorative and legible, choose legible.
If forced to choose between abstract and food-aware, stay subtle but preserve the nourishment cue.

## Files to review for context
- `/home/philip/Lip/projects/fytte_bundle/README.md`
- `/home/philip/Lip/projects/fytte_bundle/03_marketing/02_marketing_website.jsx`
- `/home/philip/Lip/projects/fytte_bundle/02_prototypes/01_onboarding.jsx`
- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/notes/fytte_brand_asset_direction.md`
- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/notes/fytte_logo_v2_brief.md`
- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/notes/fytte_leaf_logo_refinement.md`
- `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/notes/fytte_herb_gold_professional_brief.md`

## Final instruction
Do not redesign from scratch unless there is a hard implementation reason.
Use the selected Premium direction as the source of truth and translate it into production-ready assets.
