# Fytte Brand Usage Guide v1

## Core brand idea
Fytte is a premium, emotionally safe, food-aware nutrition brand.

It should feel:
- trustworthy
- calm
- polished
- intelligent
- nourishing
- wellness-forward

It should not feel like:
- gym culture
- dieting shame
- medical software
- generic AI startup branding
- eco/skincare branding

## Primary logo direction
Canonical source:
- `../logo/fytte_logo_final_premium_system_v1.png`

Selected direction:
- Premium variant
- Deep navy monogram
- Gold herb-like food cue

## Logo usage
### Primary mark
Use the deep navy + gold version whenever brand color is available.

### Monochrome versions
Use all-navy or all-white versions when production constraints require a single color.

### Backgrounds
Preferred backgrounds:
- white
- ice
- deep navy
- restrained blue gradients

Avoid placing the logo on:
- busy photography
- low-contrast mid-tone backgrounds
- coral or gold-heavy fields that reduce clarity

## Clear space
Minimum clear space around the logo should equal at least the width of the herb/leaf detail.
Do not crowd the mark with copy, buttons, or UI chrome.

## Minimum size
### Logo mark
- digital minimum: 24 px tall for icon-only use
- preferred minimum: 32 px tall

### Horizontal lockup
- digital minimum: 120 px wide
- preferred minimum: 160 px wide

If the gold leaf becomes muddy at small sizes, switch to the simplified icon version.

## Color system
### Core
- Navy: `#091F40`
- Deep: `#0D3B66`
- Blue: `#1A6FA0`
- Sky: `#2A9FD6`
- Ice: `#E1F5FE`

### Support
- Mint: `#66DDAA`
- Coral: `#FF7F6B`
- Gold: `#FFC857`
- Peach: `#FFB399`

## Color behavior
- Navy is the anchor.
- Gold is a premium accent, not a flood color.
- Mint should signal success, freshness, or healthy completion.
- Coral should be used carefully for alerts, emphasis, or warmth.
- Sky/Blue can carry gradients and interactive emphasis.

## Typography
### Display
- Playfair Display
Use for:
- wordmark-adjacent display moments
- hero statements
- editorial emphasis

### Utility and body
- DM Sans
Use for:
- UI labels
- interface text
- support copy
- screenshot captions
- product marketing body text

## Typography rules
- Do not mix in random third fonts.
- Keep display type selective and intentional.
- Favor spacious layouts over dense text blocks.

## Visual language
Prefer:
- deep navy foundations
- soft glow or restrained gradients
- premium editorial spacing
- food/nourishment cues that are subtle
- calm confidence over loud persuasion

Avoid:
- obvious salad/plate clipart
- loud rainbow gradients
- hard-tech cyber aesthetics
- fitness macho language
- dense infographic clutter

## Photography / imagery direction
If using photography:
- natural, elevated food styling
- warmth, ritual, nourishment
- clean light or rich moody editorial light
- real ingredients over synthetic perfection

Avoid:
- aggressive fitness poses
- sterile stock hospital imagery
- overly staged influencer clichés

## Splash screen guidance
Use:
- deep navy to rich blue gradient
- centered logo mark
- restrained soft glow
- elegant wordmark
- optional small tagline only

Keep it minimal.

## App icon guidance
The app icon should:
- preserve the monogram silhouette clearly
- keep the gold herb visible but not noisy
- read well on dark and light home screens
- avoid tiny interior detail

## Do / Don't
### Do
- use the selected Premium mark consistently
- keep spacing generous
- preserve the food-aware gold herb cue
- make trust and clarity win over novelty

### Don’t
- redesign the symbol casually
- swap the gold herb for a generic green leaf
- overuse gold
- distort or stretch the mark
- place the mark in crowded compositions

## Immediate production needs
1. vector recreation of selected mark
2. transparent PNG exports
3. monochrome variants
4. app icon exports
5. splash assets
6. screenshot templates
