# Fytte logo and app icon production tasks

## Objective
Turn the selected Premium logo direction into production-ready assets.

## Source of truth
- `../logo/fytte_logo_final_premium_system_v1.png`
- `../CLAUDE_XCODE_HANDOFF.md`

## Deliverables
### Logo
- primary full-color logo
- primary transparent PNG
- monochrome navy version
- monochrome white version
- horizontal lockup
- icon-only mark
- SVG if possible

### App icon
- 1024x1024 master
- simplified small-scale version if needed
- dark-background mockup
- light-background mockup

### Splash
- splash logo asset
- splash composition asset or layer spec

## Critical quality checks
- gold herb must remain visible at small sizes
- monogram silhouette must read clearly without the wordmark
- icon should feel premium, not decorative
- navy should remain the dominant brand anchor
- no extra detail that disappears on device

## Suggested file names
- `fytte-logo-primary.png`
- `fytte-logo-primary.svg`
- `fytte-logo-mark.png`
- `fytte-logo-mark-white.png`
- `fytte-logo-lockup.png`
- `fytte-app-icon-1024.png`
- `fytte-splash-logo.png`

## If simplification is needed
Prioritize:
1. silhouette clarity
2. visible gold herb cue
3. balance inside rounded-square icon
4. trustworthiness over ornament
