# Fytte Final Asset Index

This folder now contains both instruction files and the visual assets/reference images Claude should use.

## 1. Brand handoff
Instruction:
- `CLAUDE_XCODE_HANDOFF.md`

Primary visual assets:
- `logo/fytte_logo_final_premium_system_v1.png`
- `splash/fytte_splash_premium_final_v1.png`

## 2. App icon work
Instruction:
- `app-icons/FYTTE_LOGO_ICON_PRODUCTION_TASKS.md`

Visual reference:
- `app-icons/fytte_app_icon_reference_final.png`

## 3. Brand guide
Instruction:
- `guidelines/FYTTE_BRAND_USAGE_GUIDE.md`

Visual references:
- `logo/fytte_logo_final_premium_system_v1.png`
- `splash/fytte_splash_premium_final_v1.png`

## 4. App Store system
Instruction:
- `app-store/FYTTE_APP_STORE_SCREENSHOT_SYSTEM.md`

Supporting visual references:
- `app-store/fytte_splash_reference_for_marketing.png`
- `app-store/source-real-screenshots/`

## 5. Real screenshot refinement and App Store work
Instructions:
- `app-store/real-screenshot-briefs/CLAUDE_UI_REFINEMENT_BRIEF.md`
- `app-store/real-screenshot-briefs/CLAUDE_APP_STORE_REAL_SCREENSHOT_BRIEF.md`
- `app-store/real-screenshot-briefs/CLAUDE_MASTER_PROMPT_REAL_SCREENSHOTS.md`

Actual screenshot sources:
- `app-store/source-real-screenshots/01_today_or_home.jpg`
- `app-store/source-real-screenshots/02_plan_or_flow.jpg`
- `app-store/source-real-screenshots/03_explore_or_feature.jpg`
- `app-store/source-real-screenshots/04_meal_detail.jpg`
- `app-store/source-real-screenshots/05_plan_ready.jpg`
- `app-store/source-real-screenshots/06_additional_screen.jpg`

## Important note
The final generated visual assets currently available are:
- final logo system image
- final splash image
- real screenshot sources

The App Store marketing compositions still need to be produced by Claude/Xcode from the real screenshots using the attached briefs.
