# Claude UI Refinement Brief — based on real Fytte screenshots

Use the actual app screenshots as the source of truth for refinement. Do not replace them with fantasy marketing mockups. Improve the real product UI and then use the improved UI for App Store assets.

## Core instruction
Refine the existing Fytte product UI so all major screens feel like one cohesive premium product.

The current direction is good, but still reads as:
- strong prototype work
- not fully locked premium execution

Your job is to push it into:
- polished
- production-ready
- coherent
- ownable
- App Store-worthy

## Brand principles
Fytte should feel:
- premium
- calm
- food-aware
- emotionally safe
- intelligent
- trustworthy

Fytte should NOT feel like:
- a generic AI startup
- gym culture
- harsh medical software
- overdecorated wellness fluff
- a mismatched collection of prototype screens

## What to refine globally
### 1. Unify visual system
Tighten consistency across:
- card radius
- shadow softness
- spacing rhythm
- section padding
- text size hierarchy
- chip styles
- bottom nav styling
- button treatment

### 2. Reduce overuse of bright blue
The cyan/bright blue accent is currently too loud in places.

Refine color hierarchy so:
- navy stays dominant
- gold feels premium and sparse
- mint is used selectively for positive states
- coral is used sparingly for warmth/alerts
- bright blue is present but less noisy

### 3. Improve hero moments
The most important screens should feel more iconic:
- plan reveal
- meal detail
- explore
- major empty/entry states

### 4. Make data quieter and more elegant
Nutrition/stat cards should feel less like generic dashboard tiles and more like premium product information.

## Screen-specific guidance

### A. Today screen
Keep:
- warm food-led emotional tone
- useful card structure
- premium navy base

Refine:
- spacing between cards
- hierarchy between meal card, progress, and streak elements
- button/chip styling
- any overly bright accent usage

Goal:
Make Today feel like the strongest home screen in the app.

### B. Plan screen
Keep:
- weekly structure
- practicality
- food imagery

Refine:
- meal card consistency
- grocery/list hierarchy
- visual density
- selected state treatment

Goal:
Make planning feel calm, capable, and premium.

### C. Meal detail screen
Keep:
- strong food photography
- the idea of "Why Fytte picked this"
- nutrition details

Refine:
- metric/stat blocks so they feel lighter and more elegant
- the explanation card so it feels special and branded
- vertical rhythm between image, title, metadata, and body sections

Goal:
This should become one of the signature screens.

### D. Explore screen
Keep:
- editorial food image direction
- premium immersive mood

Refine:
- text placement on imagery
- overlays and safe zones
- metadata grouping
- CTA placement
- consistency with the broader product system

Goal:
Explore should feel editorial, premium, and fully integrated with the product brand.

### E. "Your plan is ready" / reveal screen
This is currently functional, not memorable enough.

Refine:
- hero composition
- ceremony/delight
- layout spacing
- stat treatment
- CTA emphasis
- reduce generic success-screen energy

Goal:
This should feel like a meaningful personalized reveal moment.

### F. Bottom navigation
Refine:
- icon weight consistency
- selected-state behavior
- central action hierarchy
- spacing and baseline alignment

Goal:
Navigation should feel quiet, premium, and obvious.

## Output expectations
Produce:
1. refined versions of the key real screens
2. consistent visual system across them
3. App Store-ready composition potential

Do not overcomplicate the UI. Prefer refinement over redesign noise.

## Decision rule
If choosing between flashy and trustworthy, choose trustworthy.
If choosing between decorative and coherent, choose coherent.
If choosing between premium and readable, keep both — but readability wins.
