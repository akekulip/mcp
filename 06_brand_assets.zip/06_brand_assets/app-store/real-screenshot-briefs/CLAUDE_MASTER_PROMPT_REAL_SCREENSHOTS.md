# Master prompt for Claude — refine UI and create App Store screenshots from real screens

Read and follow these files exactly:

1. `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/CLAUDE_XCODE_HANDOFF.md`
2. `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/guidelines/FYTTE_BRAND_USAGE_GUIDE.md`
3. `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/app-store/FYTTE_APP_STORE_SCREENSHOT_SYSTEM.md`
4. `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/app-store/real-screenshot-briefs/CLAUDE_UI_REFINEMENT_BRIEF.md`
5. `/home/philip/Lip/projects/fytte_bundle/06_brand_assets/app-store/real-screenshot-briefs/CLAUDE_APP_STORE_REAL_SCREENSHOT_BRIEF.md`

Then do the following:
- refine the real Fytte UI screens so they feel cohesive and premium
- preserve the actual product design and features
- do not replace real UI with unrelated fantasy screens
- use the selected Premium logo/brand direction consistently
- create a final App Store screenshot set based on the real screens
- prioritize trust, emotional safety, food-awareness, and premium polish

Important:
- reduce generic startup feel
- reduce overly loud blue accents where needed
- improve consistency in spacing, hierarchy, nav treatment, and card styling
- make hero screens feel more iconic without adding clutter

Deliver:
1. refined real product screens
2. App Store screenshot compositions built from those refined screens
3. any updated assets needed to support the screenshot system
