# Claude App Store Screenshot Brief — use real screenshots

Use the real Fytte screenshots as the basis for the App Store set.
Do not generate unrelated fictional UI.

## Goal
Turn real polished app screens into a premium App Store screenshot story.

The screenshots must communicate, in order:
1. personalized nutrition
2. ease of logging
3. weekly planning
4. health-aware personalization
5. emotional safety / ED Safe Mode
6. progress with kindness

## Tone
- premium
- calm
- food-aware
- emotionally safe
- trustworthy
- editorial but not abstract

## Design direction
Each screenshot should include:
- one strong headline
- optional one short support line
- real product UI as the hero
- strong spacing and safe margins
- premium background treatment aligned with Fytte brand

Keep copy minimal.
Do not overcrowd.
Do not make it look like generic startup ad creative.

## Recommended screenshot sequence

### Screenshot 1 — Today / core promise
Headline:
**Know what to eat**
Support line:
Personalized nutrition that fits your health, goals, and taste.

Use:
- strongest real Today screen

### Screenshot 2 — Logging
Headline:
**Log meals in seconds**
Support line:
Snap a photo, use your voice, or scan a barcode.

Use:
- real logging flow if available
- otherwise strongest meal capture/logging-related screen

### Screenshot 3 — Planning
Headline:
**Your week, already planned**
Support line:
Meals and groceries, organized for you.

Use:
- real Plan screen

### Screenshot 4 — Personalization
Headline:
**Built around you**
Support line:
Adapts to your goals, allergies, and health needs.

Use:
- onboarding, preferences, or health-aware configuration flow

### Screenshot 5 — Emotional safety
Headline:
**Wellness without food guilt**
Support line:
ED Safe Mode hides calories and macros when needed.

Use:
- real ED Safe Mode screen

### Screenshot 6 — Kind progress
Headline:
**Track progress, kindly**
Support line:
Streaks pause. They never punish.

Use:
- real streak, check-in, or insight screen

## Layout rules
- text must stay in safe zones
- UI should remain legible at App Store thumbnail scale
- one phone is usually enough; avoid overcomplicated multi-device layouts unless clearly improving the composition
- use premium navy-led backgrounds and restrained accents
- gold should be sparse and meaningful
- keep typography elegant and consistent

## Copy style
Use short, emotionally intelligent language.
Avoid:
- calorie obsession
- shame language
- aggressive optimization language
- exaggerated AI buzzwords

## Production goal
Create a screenshot set that sells the real product — not a fake concept version of it.

## Final rule
Make the screenshots feel like a premium, thoughtful nutrition product for real people.
Not a fitness app.
Not a generic health startup.
Not a prototype collage.
