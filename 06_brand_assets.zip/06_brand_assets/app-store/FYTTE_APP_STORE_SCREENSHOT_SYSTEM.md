# Fytte App Store Screenshot System v1

## Goal
Create a premium App Store screenshot set that sells Fytte in under 10 seconds.

The set should communicate:
1. personalized nutrition
2. ease of logging
3. weekly planning
4. emotional safety / ED Safe Mode
5. progress without punishment
6. premium trustworthy product feel

## Tone
- premium
- calm
- food-aware
- emotionally safe
- modern editorial

Avoid:
- diet culture language
- cluttered feature overload
- generic startup marketing clichés
- too much tiny text

## Suggested screenshot sequence
### Screenshot 1 — Core promise
Headline:
- **Know what to eat.**
Subhead:
- Personalized nutrition that fits your health, goals, and taste.
Visual:
- strongest Today/home screen
- premium hero framing
- logo small if needed

### Screenshot 2 — Easy logging
Headline:
- **Log meals in seconds**
Subhead:
- Snap a photo, use your voice, or scan a barcode.
Visual:
- log flow / AI analysis / review screens

### Screenshot 3 — Weekly planning
Headline:
- **Your week, already planned**
Subhead:
- Daily meals plus an auto-built grocery list.
Visual:
- Plan tab + grocery state

### Screenshot 4 — Health-aware personalization
Headline:
- **Built around you**
Subhead:
- Adapts to allergies, pregnancy, goals, and health needs.
Visual:
- onboarding or profile update screens

### Screenshot 5 — Emotionally safer wellness
Headline:
- **Wellness without food guilt**
Subhead:
- ED Safe Mode hides calories and macros when needed.
Visual:
- ED Safe Mode screens

### Screenshot 6 — Progress with kindness
Headline:
- **Track progress, kindly**
Subhead:
- Streaks pause. They never punish.
Visual:
- streak/check-in/insights screens

## Layout rules
- one strong headline per screen
- one short support line max
- big device framing
- generous margins
- keep text in safe areas
- maintain hierarchy: headline > device > support line > small brand cue

## Typography
- Headline: Playfair Display or premium editorial style
- Support copy: DM Sans
- Keep headlines short and emotionally resonant

## Color strategy
- use navy/deep blue as primary stage
- use gold sparingly for premium emphasis
- use mint/coral as selective emotional accents
- keep each screenshot composition controlled, not rainbow

## Device presentation
Preferred:
- one large iPhone mockup
- or one hero phone plus one supporting inset if necessary

Avoid:
- too many floating phones
- tiny unreadable UI
- overly busy background motifs

## Suggested export set
- 1290 x 2796 px (6.9-inch reference, if targeting large iPhone first)
- also adapt for other App Store sizes as needed

## Production checklist
- verify text safe zones
- verify headline consistency
- verify UI is readable at thumbnail scale
- keep gold use restrained and intentional
- ensure emotional safety language remains soft and credible
